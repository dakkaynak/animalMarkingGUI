%  
% OptProp\colordiffs
% Version 2.0   1 December 2006
% 
%   de     - Calculate CIELAB DeltaE.
%   de2000 - Calculate DeltaE(2000).
%   de94   - Calculate DeltaE(94).
