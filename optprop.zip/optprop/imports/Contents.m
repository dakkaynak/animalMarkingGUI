%  
% OptProp\imports
% Version 2.0   1 December 2006
% 
%   gridfit - estimates a surface on a 2d grid, based on scattered data
%   isnear  - True Where Nearly Equal.
%   onoff   - ON/OFF to/from Boolean Conversion.
